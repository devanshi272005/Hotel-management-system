package com.databaseconnectivity.hotelbookingsystem.controller;

import java.util.Scanner;

public class TransactionsController {

    private Scanner sc = new Scanner(System.in);

    public TransactionsController(Scanner sc2) {
		// TODO Auto-generated constructor stub
	}

	public void menu() {
        int choice;

        do {
            System.out.println("\n--- TRANSACTIONS MENU ---");
            System.out.println("1. Add Transaction");
            System.out.println("2. View Transactions");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Add Transaction logic");
                    break;
                case 2:
                    System.out.println("View Transactions logic");
                    break;
                case 0:
                    System.out.println("Back to Main Menu...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 0);
    }
}
