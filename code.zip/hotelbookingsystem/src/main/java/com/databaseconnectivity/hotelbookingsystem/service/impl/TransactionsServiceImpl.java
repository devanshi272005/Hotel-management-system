package com.databaseconnectivity.hotelbookingsystem.service.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.TransactionsDao;
import com.databaseconnectivity.hotelbookingsystem.dao.impl.TransactionsDaoImpl;
import com.databaseconnectivity.hotelbookingsystem.model.Transactions;
import com.databaseconnectivity.hotelbookingsystem.service.TransactionsService;

import java.util.List;

public class TransactionsServiceImpl implements TransactionsService {

    private TransactionsDao transactionDAO = new TransactionsDaoImpl();

    @Override
    public void addTransactions(Transactions transaction) {
        transactionDAO.addTransactions(transaction);
    }

    @Override
    public List<Transactions> getTransactionsByBooking(int bookingId) {
        return transactionDAO.getTransactionsByBooking(bookingId);
    }
}
