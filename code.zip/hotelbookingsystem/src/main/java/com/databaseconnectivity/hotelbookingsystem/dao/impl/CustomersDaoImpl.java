package com.databaseconnectivity.hotelbookingsystem.dao.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.CustomersDao;
import com.databaseconnectivity.hotelbookingsystem.model.Customers;
import com.databaseconnectivity.hotelbookingsystem.util.DataBaseConnectionUtil;

import java.sql.*;
import java.util.*;

public  class CustomersDaoImpl implements CustomersDao {

    @Override
    public void addCustomers(Customers c) {
        String sql =
            "INSERT INTO customer(name, phone, email, address) VALUES (?, ?, ?, ?)";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getAddress());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Customers getCustomersById(int id) {
        String sql = "SELECT * FROM customer WHERE customer_id=?";
        Customers c = null;

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                c = new Customers(
                    rs.getInt("customer_id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("address")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return c;
    }

    @Override
    public List<Customers> getAllCustomers() {
        List<Customers> list = new ArrayList<>();
        String sql = "SELECT * FROM customer";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Customers(
                    rs.getInt("customer_id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("address")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void updateCustomers(Customers c) {
        String sql =
            "UPDATE customer SET name=?, phone=?, email=?, address=? WHERE customer_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, c.getName());
            ps.setString(2, c.getPhone());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getAddress());
            ps.setInt(5, c.getCustomer_id());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteCustomers(int id) {
        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps =
                     con.prepareStatement("DELETE FROM customer WHERE customer_id=?")) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
