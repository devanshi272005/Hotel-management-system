package com.databaseconnectivity.hotelbookingsystem.dao;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Customers;

public interface CustomersDao {
  void addCustomers(Customers customer);
  Customers getCustomersById(int id);
  List<Customers> getAllCustomers();
  void updateCustomers(Customers customers);
  void deleteCustomers(int id);
}
