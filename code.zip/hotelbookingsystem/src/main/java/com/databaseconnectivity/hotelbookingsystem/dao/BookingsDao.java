package com.databaseconnectivity.hotelbookingsystem.dao;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Bookings;

public interface BookingsDao {
     void addBookings(Bookings bookings);
     Bookings getBookingsById(int id);
     List<Bookings> getAllBookings();
     void updateBookings(int id, String status);
     void deleteBookings(int id);
	 void updateBookingsStatus(int id, String status);
}
