package com.databaseconnectivity.hotelbookingsystem.service.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.RoomTypeDao;
import com.databaseconnectivity.hotelbookingsystem.dao.impl.RoomTypeDAOImpl;
import com.databaseconnectivity.hotelbookingsystem.model.RoomType;
import com.databaseconnectivity.hotelbookingsystem.service.RoomTypeService;

import java.util.List;

public class RoomTypeServiceImpl implements RoomTypeService {

    private RoomTypeDao roomTypeDAO = new RoomTypeDAOImpl();

    @Override
    public void addRoomType(RoomType roomType) {
        roomTypeDAO.addRoomType(roomType);
    }

    public RoomType getRoomTypeById1(int id) {
        return roomTypeDAO.getRoomTypeById(id);
    }

    public List<RoomType> getAllRoomTypes() {
        return roomTypeDAO.getAllRoomTypes();
    }

    @Override
    public void updateRoomType(RoomType roomType) {
        roomTypeDAO.updateRoomType(roomType);
    }

    @Override
    public void deleteRoomType(int id) {
        roomTypeDAO.deleteRoomType(id);
    }

	@Override
	public List<RoomType> getAllRoomType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RoomType getRoomTypeById(int id) {
		// TODO Auto-generated method stub
		return null;
	}
}
