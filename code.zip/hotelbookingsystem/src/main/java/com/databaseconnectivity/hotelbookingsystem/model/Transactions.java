package com.databaseconnectivity.hotelbookingsystem.model;

import java.math.BigDecimal;

import java.sql.Timestamp;

public class Transactions {
      private int transaction_id;
      private int booking_id;
      private String payment_mode;
      private BigDecimal amount_paid;
      private Timestamp date;
	  public Transactions() {
		super();
		// TODO Auto-generated constructor stub
	  }
	  public Transactions(int transaction_id, int booking_id, String payment_mode, BigDecimal amount_paid,
			Timestamp date) {
		super();
		this.transaction_id = transaction_id;
		this.booking_id = booking_id;
		this.payment_mode = payment_mode;
		this.amount_paid = amount_paid;
		this.date = date;
	  }
	  public int getTransaction_id() {
		  return transaction_id;
	  }
	  public void setTransaction_id(int transaction_id) {
		  this.transaction_id = transaction_id;
	  }
	  public int getBooking_id() {
		  return booking_id;
	  }
	  public void setBooking_id(int booking_id) {
		  this.booking_id = booking_id;
	  }
	  public String getPayment_mode() {
		  return payment_mode;
	  }
	  public void setPayment_mode(String payment_mode) {
		  this.payment_mode = payment_mode;
	  }
	  public BigDecimal getAmount_paid() {
		  return amount_paid;
	  }
	  public void setAmount_paid(BigDecimal amount_paid) {
		  this.amount_paid = amount_paid;
	  }
	  public Timestamp getDate() {
		  return date;
	  }
	  public void setDate(Timestamp date) {
		  this.date = date;
	  }
	  @Override
	  public String toString() {
		return "Transactions [transaction_id=" + transaction_id + ", booking_id=" + booking_id + ", payment_mode="
				+ payment_mode + ", getTransaction_id()=" + getTransaction_id() + ", getBooking_id()=" + getBooking_id()
				+ ", getPayment_mode()=" + getPayment_mode() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	  }
      
}
