package com.databaseconnectivity.hotelbookingsystem.controller;

import java.util.Scanner;

public class BookingsController {

    private Scanner sc = new Scanner(System.in);

    public BookingsController(Scanner sc2) {
		// TODO Auto-generated constructor stub
	}

	public void menu() {
        int choice;

        do {
            System.out.println("\n--- BOOKING MENU ---");
            System.out.println("1. Create Booking");
            System.out.println("2. View Bookings");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Create Booking logic");
                    break;
                case 2:
                    System.out.println("View Bookings logic");
                    break;
                case 0:
                    System.out.println("Back to Main Menu...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 0);
    }
}
