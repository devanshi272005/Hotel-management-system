package com.databaseconnectivity.hotelbookingsystem.dao;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Rooms;

public interface RoomsDao {
    void addRooms(Rooms rooms);
    Rooms getRoomsById(int id);
    List<Rooms> getAllRooms();
    List<Rooms> getRoomsByType(String typeId);
    void updateRooms(Rooms rooms);
    void deleteRooms(String id);
	void updateRoomsStatus(int id, String status);
}
