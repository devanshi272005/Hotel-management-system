package com.databaseconnectivity.hotelbookingsystem.controller;

import java.util.Scanner;

public class RoomTypeController {

    private Scanner sc = new Scanner(System.in);

    public RoomTypeController(Scanner sc2) {
		// TODO Auto-generated constructor stub
	}

	public void menu() {
        int choice;

        do {
            System.out.println("\n--- ROOM TYPE MENU ---");
            System.out.println("1. Add Room Type");
            System.out.println("2. View Room Types");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Add Room Type logic");
                    break;
                case 2:
                    System.out.println("View Room Types logic");
                    break;
                case 0:
                    System.out.println("Back to Main Menu...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 0);
    }
}
