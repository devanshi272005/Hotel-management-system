package com.databaseconnectivity.hotelbookingsystem.service.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.BookingsDao;
import com.databaseconnectivity.hotelbookingsystem.dao.impl.BookingsDaoImpl;
import com.databaseconnectivity.hotelbookingsystem.model.Bookings;
import com.databaseconnectivity.hotelbookingsystem.service.BookingsService;

import java.util.List;

public class BookingsServiceImpl implements BookingsService {

    private BookingsDao bookingDAO = new BookingsDaoImpl();

    @Override
    public void createBookings(Bookings booking) {
        bookingDAO.addBookings(booking);
    }

    @Override
    public Bookings getBookingsById(int id) {
        return bookingDAO.getBookingsById(id);
    }

    @Override
    public List<Bookings> getAllBookings() {
        return bookingDAO.getAllBookings();
    }

    @Override
    public void cancelBookings(int id) {
        bookingDAO.updateBookingsStatus(id, "CANCELLED");
    }

	@Override
	public void addBooking(Bookings booking) {
		// TODO Auto-generated method stub
		
	}
}
