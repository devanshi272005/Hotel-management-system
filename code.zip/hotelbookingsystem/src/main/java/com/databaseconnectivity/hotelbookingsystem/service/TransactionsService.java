package com.databaseconnectivity.hotelbookingsystem.service;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Transactions;

public interface TransactionsService {
    void addTransactions(Transactions transaction);
    List<Transactions> getTransactionsByBooking(int bookingId);
}
