package com.databaseconnectivity.hotelbookingsystem.controller;

import java.util.Scanner;

public class RoomsController {

    public RoomsController(Scanner sc) {
		// TODO Auto-generated constructor stub
	}

	public void menu() {

        try (Scanner sc = new Scanner(System.in)) {
			int choice;

			do {
			    System.out.println("\n--- ROOM MENU ---");
			    System.out.println("1. Add Room");
			    System.out.println("2. View Rooms");
			    System.out.println("0. Back");
			    System.out.print("Enter choice: ");

			    choice = sc.nextInt();

			    switch (choice) {
			        case 1:
			            System.out.println("Add Room logic");
			            break;
			        case 2:
			            System.out.println("View Rooms logic");
			            break;
			        case 0:
			            System.out.println("Back to Main Menu...");
			            break;
			        default:
			            System.out.println("Invalid choice!");
			    }

			} while (choice != 0);
		}
    }
}
