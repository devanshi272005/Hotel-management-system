package com.databaseconnectivity.hotelbookingsystem.model;

import java.math.BigDecimal;

public class RoomType {

    private int typeId;
    private String typeName;
    private BigDecimal pricePerDay;

    public RoomType(int typeId, String typeName, BigDecimal pricePerDay) {
        this.typeId = typeId;
        this.typeName = typeName;
        this.pricePerDay = pricePerDay;
    }

    public int getTypeId() {
        return typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public BigDecimal getPricePerDay() {
        return pricePerDay;
    }

    @Override
    public String toString() {
        return typeId + " | " + typeName + " | " + pricePerDay;
    }
}
