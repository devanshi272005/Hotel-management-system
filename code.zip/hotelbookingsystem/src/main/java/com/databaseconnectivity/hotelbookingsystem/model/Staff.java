package com.databaseconnectivity.hotelbookingsystem.model;

public class Staff {
  private int staff_id;
  private String name;
  private String role;
  private String phone;
  private String shift_time;
  public Staff() {
	super();
	// TODO Auto-generated constructor stub
  }
  public Staff(int staff_id, String name, String role, String phone, String shift_time) {
	super();
	this.staff_id = staff_id;
	this.name = name;
	this.role = role;
	this.phone = phone;
	this.shift_time = shift_time;
  }
  public int getStaff_id() {
	return staff_id;
  }
  public void setStaff_id(int staff_id) {
	this.staff_id = staff_id;
  }
  public String getName() {
	return name;
  }
  public void setName(String name) {
	this.name = name;
  }
  public String getRole() {
	return role;
  }
  public void setRole(String role) {
	this.role = role;
  }
  public String getPhone() {
	return phone;
  }
  public void setPhone(String phone) {
	this.phone = phone;
  }
  public String getShift_time() {
	return shift_time;
  }
  public void setShift_time(String shift_time) {
	this.shift_time = shift_time;
  }
  @Override
  public String toString() {
	return "Staff [staff_id=" + staff_id + ", name=" + name + ", role=" + role + ", phone=" + phone + ", shift_time="
			+ shift_time + ", getStaff_id()=" + getStaff_id() + ", getName()=" + getName() + ", getRole()=" + getRole()
			+ ", getPhone()=" + getPhone() + ", getShift_time()=" + getShift_time() + ", getClass()=" + getClass()
			+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
  }
  
}
