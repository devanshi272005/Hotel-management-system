package com.databaseconnectivity.hotelbookingsystem.dao.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.TransactionsDao;
import com.databaseconnectivity.hotelbookingsystem.model.Transactions;
import com.databaseconnectivity.hotelbookingsystem.util.DataBaseConnectionUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionsDaoImpl implements TransactionsDao {

    @Override
    public void addTransactions(Transactions t) {
        String sql =
            "INSERT INTO transactions (booking_id, payment_mode, amount_paid, transaction_date) " +
            "VALUES (?, ?, ?, ?)";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, t.getBooking_id());
            ps.setString(2, t.getPayment_mode());
            ps.setBigDecimal(3, t.getAmount_paid());
            ps.setTimestamp(4, t.getDate());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Transactions> getTransactionsByBooking(int bookingId) {
        List<Transactions> list = new ArrayList<>();
        String sql = "SELECT * FROM transactions WHERE booking_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, bookingId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Transactions(
                        rs.getInt("transaction_id"),
                        rs.getInt("booking_id"),
                        rs.getString("payment_mode"),
                        rs.getBigDecimal("amount_paid"),
                        rs.getTimestamp("transaction_date")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
