package com.databaseconnectivity.hotelbookingsystem.dao;

import com.databaseconnectivity.hotelbookingsystem.model.RoomType;
import java.util.List;

public interface RoomTypeDao {

    void addRoomType(RoomType roomType);

    RoomType getRoomTypeById(int id);

    List<RoomType> getAllRoomTypes();

    void updateRoomType(RoomType roomType);

    void deleteRoomType(int id);
}
