package com.databaseconnectivity.hotelbookingsystem.service.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.RoomsDao;
import com.databaseconnectivity.hotelbookingsystem.dao.impl.RoomsDaoImpl;
import com.databaseconnectivity.hotelbookingsystem.model.Rooms;
import com.databaseconnectivity.hotelbookingsystem.service.RoomsService;

import java.util.List;

public class RoomsServiceImpl implements RoomsService {

    private RoomsDao roomDAO = new RoomsDaoImpl();

    @Override
    public void addRooms(Rooms room) {
        roomDAO.addRooms(room);
    }

    @Override
    public Rooms getRoomsById(int id) {
        return roomDAO.getRoomsById(id);
    }

    @Override
    public List<Rooms> getAllRooms() {
        return roomDAO.getAllRooms();
    }

    public void updateRoomsStatus(int id, String status) {
        roomDAO.updateRoomsStatus(id, status);
    }

	@Override
	public void updateRoomStatus(int id, String status) {
		// TODO Auto-generated method stub
		
	}
}
