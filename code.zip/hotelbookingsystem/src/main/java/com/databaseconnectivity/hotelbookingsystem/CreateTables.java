package com.databaseconnectivity.hotelbookingsystem;

import java.sql.Connection;
import java.sql.Statement;

import com.databaseconnectivity.hotelbookingsystem.util.DataBaseConnectionUtil;

public class CreateTables {
  public static void main(String[] args) {
	  String createRoomTypeTable =
              "CREATE TABLE IF NOT EXISTS room_type (" +
              "type_id INT PRIMARY KEY, " +
              "type_name VARCHAR(50) NOT NULL, " +
              "price_per_day DECIMAL(10,2) NOT NULL)";

          String createRoomTable =
              "CREATE TABLE IF NOT EXISTS room (" +
              "room_id INT PRIMARY KEY, " +
              "room_number VARCHAR(20) NOT NULL, " +
              "type_id INT NOT NULL, " +
              "status VARCHAR(20) NOT NULL, " +
              "FOREIGN KEY(type_id) REFERENCES room_type(type_id)" +
              ") ENGINE=InnoDB";

          String createCustomerTable =
              "CREATE TABLE IF NOT EXISTS customer (" +
              "customer_id INT PRIMARY KEY, " +
              "name VARCHAR(100) NOT NULL, " +
              "phone VARCHAR(15) NOT NULL, " +
              "email VARCHAR(100) NOT NULL, " +
              "address VARCHAR(150) NOT NULL)";

          String createBookingTable =
              "CREATE TABLE IF NOT EXISTS booking (" +
              "booking_id INT PRIMARY KEY, " +
              "room_id INT NOT NULL, " +
              "customer_id INT NOT NULL," +
              "check_in_date DATE NOT NULL, " +
              "check_out_date DATE NOT NULL, " +
              "total_amount DECIMAL(10,2) NOT NULL, " +
              "booking_status VARCHAR(20) NOT NULL, " +
              "FOREIGN KEY(room_id) REFERENCES room(room_id), " +
              "FOREIGN KEY(customer_id) REFERENCES customer(customer_id)" +
              ") ENGINE=InnoDB";

          String createTransactionDetailsTable =
              "CREATE TABLE IF NOT EXISTS transactions (" +
              "transaction_id INT PRIMARY KEY, " +
              "booking_id INT NOT NULL, " +
              "payment_mode VARCHAR(50) NOT NULL, " +
              "amount_paid DECIMAL(10,2) NOT NULL, " +
              "transaction_date DATE NOT NULL, " +
              "FOREIGN KEY(booking_id) REFERENCES booking(booking_id)" +
              ") ENGINE=InnoDB";

          String createStaffTable =
              "CREATE TABLE IF NOT EXISTS staff (" +
              "staff_id INT PRIMARY KEY, " +
              "name VARCHAR(100) NOT NULL, " +
              "role VARCHAR(50) NOT NULL, " +
              "phone VARCHAR(15) NOT NULL, " +
              "shift_time VARCHAR(20) NOT NULL)" +
              ") ENGINE=InnoDB";
          try(Connection con= DataBaseConnectionUtil.getConnection();
        		  Statement stmt = con.createStatement()){
        	  stmt.executeUpdate(createRoomTypeTable);
        	  stmt.executeUpdate(createRoomTable);
        	  stmt.executeUpdate(createCustomerTable);
        	  stmt.executeUpdate(createBookingTable);
        	  stmt.executeUpdate(createTransactionDetailsTable);
        	  stmt.executeUpdate(createStaffTable);
        	  System.out.println("All tables created successfully");
          } catch(Exception e) {
        	  e.printStackTrace();
          }
  }
}
