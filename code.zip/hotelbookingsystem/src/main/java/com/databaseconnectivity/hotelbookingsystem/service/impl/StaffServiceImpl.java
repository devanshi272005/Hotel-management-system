package com.databaseconnectivity.hotelbookingsystem.service.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.StaffDao;
import com.databaseconnectivity.hotelbookingsystem.dao.impl.StaffDaoImpl;
import com.databaseconnectivity.hotelbookingsystem.model.Staff;
import com.databaseconnectivity.hotelbookingsystem.service.StaffService;

import java.util.List;

public class StaffServiceImpl implements StaffService {

    private StaffDao staffDAO = new StaffDaoImpl();

    @Override
    public void addStaff(Staff staff) {
        staffDAO.addStaff(staff);
    }

    @Override
    public Staff getStaffById(int id) {
        return staffDAO.getStaffById(id);
    }

    @Override
    public List<Staff> getAllStaff() {
        return staffDAO.getAllStaff();
    }

    @Override
    public void updateStaff(Staff staff) {
        staffDAO.updateStaff(staff);
    }

    @Override
    public void deleteStaff(int id) {
        staffDAO.deleteStaff(id);
    }
}
