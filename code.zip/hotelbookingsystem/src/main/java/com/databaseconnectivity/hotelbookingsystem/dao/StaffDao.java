package com.databaseconnectivity.hotelbookingsystem.dao;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Staff;

public interface StaffDao {
   void addStaff(Staff staff);
   Staff getStaffById(int id);
   List<Staff> getAllStaff();
   void updateStaff(Staff staff);
   void deleteStaff(int id);
}
