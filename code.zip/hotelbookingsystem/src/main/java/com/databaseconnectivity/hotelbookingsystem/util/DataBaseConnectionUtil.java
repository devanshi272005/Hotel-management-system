package com.databaseconnectivity.hotelbookingsystem.util;
import java.sql.*;
public class DataBaseConnectionUtil{
    private static final String url= "jdbc:mysql://localhost:3306/hotelbookingsystem";
    private static final String username="root";
    private static final String password="devanshi@1234";
    public static Connection getConnection() {
         Connection con=null;
         try {
        	 con= DriverManager.getConnection(url,username,password);
         }
         catch(SQLException e) {
        	 e.printStackTrace();
         }
         return con;
    }
}


