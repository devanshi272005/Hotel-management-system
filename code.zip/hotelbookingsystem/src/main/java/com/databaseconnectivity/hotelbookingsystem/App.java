package com.databaseconnectivity.hotelbookingsystem;

import com.databaseconnectivity.hotelbookingsystem.controller.MainController;

public class App {

    public static void main(String[] args) {
        new MainController().start();
    }
}
