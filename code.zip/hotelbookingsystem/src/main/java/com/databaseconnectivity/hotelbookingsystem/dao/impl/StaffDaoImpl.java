package com.databaseconnectivity.hotelbookingsystem.dao.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.StaffDao;
import com.databaseconnectivity.hotelbookingsystem.model.Staff;
import com.databaseconnectivity.hotelbookingsystem.util.DataBaseConnectionUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StaffDaoImpl implements StaffDao {

    @Override
    public void addStaff(Staff staff) {
        String sql = "INSERT INTO staff(name) VALUES (?)";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, staff.getName());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Staff getStaffById(int id) {
        String sql = "SELECT * FROM staff WHERE staff_id=?";
        Staff staff = null;

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                staff = new Staff(
                        rs.getInt("staff_id"),
                        rs.getString("name"), sql, sql, sql
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return staff;
    }

    @Override
    public List<Staff> getAllStaff() {
        List<Staff> list = new ArrayList<>();
        String sql = "SELECT * FROM staff";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Staff(
                        rs.getInt("staff_id"),
                        rs.getString("name"), sql, sql, sql
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void updateStaff(Staff staff) {
        String sql = "UPDATE staff SET name=? WHERE staff_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, staff.getName());
            ps.setInt(2, staff.getStaff_id());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteStaff(int id) {
        String sql = "DELETE FROM staff WHERE staff_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
