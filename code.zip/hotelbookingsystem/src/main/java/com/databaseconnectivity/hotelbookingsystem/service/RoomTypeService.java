package com.databaseconnectivity.hotelbookingsystem.service;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.RoomType;

public interface RoomTypeService {
     void addRoomType(RoomType roomType);
     RoomType getRoomTypeById(int id);
     List<RoomType> getAllRoomType();
     void updateRoomType(RoomType roomType);
     void deleteRoomType(int id);
}
