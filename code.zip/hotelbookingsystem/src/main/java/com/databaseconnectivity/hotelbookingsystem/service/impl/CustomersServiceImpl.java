package com.databaseconnectivity.hotelbookingsystem.service.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.CustomersDao;
import com.databaseconnectivity.hotelbookingsystem.dao.impl.CustomersDaoImpl;
import com.databaseconnectivity.hotelbookingsystem.model.Customers;
import com.databaseconnectivity.hotelbookingsystem.service.CustomersService;

import java.util.List;

public class CustomersServiceImpl implements CustomersService {

    private CustomersDao customerDAO = new CustomersDaoImpl();

    @Override
    public void addCustomers(Customers customers) {
        customerDAO.addCustomers(customers);
    }

    @Override
    public Customers getCustomersById(int id) {
        return customerDAO.getCustomersById(id);
    }

    @Override
    public List<Customers> getAllCustomers() {
        return customerDAO.getAllCustomers();
    }

    @Override
    public void updateCustomers(Customers customer) {
        customerDAO.updateCustomers(customer);
    }

    @Override
    public void deleteCustomers(int id) {
        customerDAO.deleteCustomers(id);
    }
}
