package com.databaseconnectivity.hotelbookingsystem.service;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Bookings;

public interface BookingsService {
     void createBookings(Bookings bookings);
     Bookings getBookingsById(int id);
     List<Bookings> getAllBookings();
     void cancelBookings(int id);
	 void addBooking(Bookings booking);
}
