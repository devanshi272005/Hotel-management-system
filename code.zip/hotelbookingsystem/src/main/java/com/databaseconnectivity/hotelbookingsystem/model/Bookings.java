package com.databaseconnectivity.hotelbookingsystem.model;

import java.math.BigDecimal;

import java.sql.Timestamp;

public class Bookings {

    private int booking_id;
    private int customer_id;
    private int room_id;
    private Timestamp check_in_date;
    private Timestamp check_out_date;
    private BigDecimal total_amount;
    private String booking_status;
	public Bookings() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bookings(int booking_id, int customer_id, int room_id, Timestamp check_in_date, Timestamp check_out_date,
			BigDecimal total_amount, String booking_status) {
		super();
		this.booking_id = booking_id;
		this.customer_id = customer_id;
		this.room_id = room_id;
		this.check_in_date = check_in_date;
		this.check_out_date = check_out_date;
		this.total_amount = total_amount;
		this.booking_status = booking_status;
	}
	public int getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public int getRoom_id() {
		return room_id;
	}
	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}
	public Timestamp getCheck_in_date() {
		return check_in_date;
	}
	public void setCheck_in_date(Timestamp check_in_date) {
		this.check_in_date = check_in_date;
	}
	public Timestamp getCheck_out_date() {
		return check_out_date;
	}
	public void setCheck_out_date(Timestamp check_out_date) {
		this.check_out_date = check_out_date;
	}
	public BigDecimal getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(BigDecimal total_amount) {
		this.total_amount = total_amount;
	}
	public String getBooking_status() {
		return booking_status;
	}
	public void setBooking_status(String booking_status) {
		this.booking_status = booking_status;
	}
	@Override
	public String toString() {
		return "Bookings [booking_id=" + booking_id + ", customer_id=" + customer_id + ", room_id=" + room_id
				+ ", check_in_date=" + check_in_date + ", check_out_date=" + check_out_date + ", total_amount="
				+ total_amount + ", booking_status=" + booking_status + ", getBooking_id()=" + getBooking_id()
				+ ", getCustomer_id()=" + getCustomer_id() + ", getRoom_id()=" + getRoom_id() + ", getCheck_in_date()="
				+ getCheck_in_date() + ", getCheck_out_date()=" + getCheck_out_date() + ", getTotal_amount()="
				+ getTotal_amount() + ", getBooking_status()=" + getBooking_status() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}

    