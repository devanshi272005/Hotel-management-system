package com.databaseconnectivity.hotelbookingsystem.dao.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.RoomTypeDao;
import com.databaseconnectivity.hotelbookingsystem.model.RoomType;
import com.databaseconnectivity.hotelbookingsystem.util.DataBaseConnectionUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RoomTypeDAOImpl implements RoomTypeDao {

    @Override
    public void addRoomType(RoomType roomType) {

        String sql = "INSERT INTO room_type VALUES (?, ?, ?)";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, roomType.getTypeId());
            ps.setString(2, roomType.getTypeName());
            ps.setBigDecimal(3, roomType.getPricePerDay());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public RoomType getRoomTypeById(int id) {

        String sql = "SELECT * FROM room_type WHERE type_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new RoomType(
                        rs.getInt("type_id"),
                        rs.getString("type_name"),
                        rs.getBigDecimal("price_per_day")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<RoomType> getAllRoomTypes() {

        List<RoomType> list = new ArrayList<>();
        String sql = "SELECT * FROM room_type";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new RoomType(
                        rs.getInt("type_id"),
                        rs.getString("type_name"),
                        rs.getBigDecimal("price_per_day")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void updateRoomType(RoomType roomType) {

        String sql = "UPDATE room_type SET type_name=?, price_per_day=? WHERE type_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, roomType.getTypeName());
            ps.setBigDecimal(2, roomType.getPricePerDay());
            ps.setInt(3, roomType.getTypeId());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteRoomType(int id) {

        String sql = "DELETE FROM room_type WHERE type_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
