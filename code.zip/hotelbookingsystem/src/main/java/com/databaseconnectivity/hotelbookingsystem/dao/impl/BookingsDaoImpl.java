package com.databaseconnectivity.hotelbookingsystem.dao.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.BookingsDao;
import com.databaseconnectivity.hotelbookingsystem.model.Bookings;
import com.databaseconnectivity.hotelbookingsystem.util.DataBaseConnectionUtil;

import java.sql.*;
import java.util.*;

public class BookingsDaoImpl implements BookingsDao {

    @Override
    public void addBookings(Bookings b) {
        String sql =
          "INSERT INTO booking(room_id, customer_id, check_in_date, check_out_date, total_amount, booking_status) " +
          "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, b.getRoom_id());
            ps.setInt(2, b.getCustomer_id());
            ps.setTimestamp(3, b.getCheck_in_date());
            ps.setTimestamp(4, b.getCheck_out_date());
            ps.setBigDecimal(5, b.getTotal_amount());
            ps.setString(6, b.getBooking_status());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Bookings getBookingsById(int id) {
        String sql = "SELECT * FROM booking WHERE booking_id=?";
        Bookings b = null;

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                b = new Bookings(
                    rs.getInt("booking_id"),
                    rs.getInt("room_id"),
                    rs.getInt("customer_id"),
                    rs.getTimestamp("check_in_date"),
                    rs.getTimestamp("check_out_date"),
                    rs.getBigDecimal("total_amount"),
                    rs.getString("booking_status")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }

    @Override
    public List<Bookings> getAllBookings() {
        List<Bookings> list = new ArrayList<>();
        String sql = "SELECT * FROM booking";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Bookings(
                    rs.getInt("booking_id"),
                    rs.getInt("room_id"),
                    rs.getInt("customer_id"),
                    rs.getTimestamp("check_in_date"),
                    rs.getTimestamp("check_out_date"),
                    rs.getBigDecimal("total_amount"),
                    rs.getString("booking_status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void updateBookingsStatus(int id, String status) {
        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps =
                     con.prepareStatement("UPDATE booking SET booking_status=? WHERE booking_id=?")) {

            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteBookings(int id) {
        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps =
                     con.prepareStatement("DELETE FROM booking WHERE booking_id=?")) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	@Override
	public void updateBookings(int id, String status) {
		// TODO Auto-generated method stub
		
	}
}
