package com.databaseconnectivity.hotelbookingsystem.dao.impl;

import com.databaseconnectivity.hotelbookingsystem.dao.RoomsDao;
import com.databaseconnectivity.hotelbookingsystem.model.Rooms;
import com.databaseconnectivity.hotelbookingsystem.util.DataBaseConnectionUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public  class RoomsDaoImpl implements RoomsDao {

    @Override
    public void addRooms(Rooms rooms) {
        String sql =
            "INSERT INTO room (room_number, type_id, status) VALUES (?, ?, ?)";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, rooms.getRoom_number());
            ps.setInt(2, rooms.getType_id());
            ps.setString(3, rooms.getStatus());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Rooms getRoomsById(int id) {
        String sql = "SELECT * FROM room WHERE room_id=?";
        Rooms room = null;

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                room = new Rooms(
                        rs.getInt("room_id"),
                        rs.getString("room_number"),
                        rs.getInt("type_id"),
                        rs.getString("status")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return room;
    }

    @Override
    public List<Rooms> getAllRooms() {
        List<Rooms> list = new ArrayList<>();
        String sql = "SELECT * FROM room";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Rooms(
                        rs.getInt("room_id"),
                        rs.getString("room_number"),
                        rs.getInt("type_id"),
                        rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Rooms> getRoomsByType(String typeId) {
        List<Rooms> list = new ArrayList<>();
        String sql = "SELECT * FROM room WHERE type_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, typeId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Rooms(
                        rs.getInt("room_id"),
                        rs.getString("room_number"),
                        rs.getInt("type_id"),
                        rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void updateRooms(Rooms rooms) {
        String sql =
            "UPDATE room SET room_number=?, type_id=?, status=? WHERE room_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, rooms.getRoom_number());
            ps.setInt(2, rooms.getType_id());
            ps.setString(3, rooms.getStatus());
            ps.setInt(4, rooms.getRoom_id());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteRooms(String id) {
        String sql = "DELETE FROM room WHERE room_id=?";

        try (Connection con = DataBaseConnectionUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	@Override
	public void updateRoomsStatus(int id, String status) {
		// TODO Auto-generated method stub
		
	}
}
