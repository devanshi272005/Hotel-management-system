package com.databaseconnectivity.hotelbookingsystem.controller;

import java.util.Scanner;

public class MainController {

    private Scanner sc = new Scanner(System.in);

    public void start() {
        int choice;

        do {
            System.out.println("\n===== HOTEL BOOKING SYSTEM =====");
            System.out.println("1. Room Types");
            System.out.println("2. Rooms");
            System.out.println("3. Customers");
            System.out.println("4. Bookings");
            System.out.println("5. Transactions");
            System.out.println("6. Staff");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    new RoomTypeController(sc).menu();
                    break;
                case 2:
                    new RoomsController(sc).menu();
                    break;
                case 3:
                    new CustomersController(sc).menu();
                    break;
                case 4:
                    new BookingsController(sc).menu();
                    break;
                case 5:
                    new TransactionsController(sc).menu();
                    break;
                case 6:
                    new StaffController(sc).menu();
                    break;
                case 0:
                    System.out.println("Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 0);
    }
}
