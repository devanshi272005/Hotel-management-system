package com.databaseconnectivity.hotelbookingsystem.service;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Staff;

public interface StaffService {
    void addStaff(Staff staff);
    Staff getStaffById(int id);
    List<Staff> getAllStaff();
    void updateStaff(Staff staff);
    void deleteStaff(int id);
}
