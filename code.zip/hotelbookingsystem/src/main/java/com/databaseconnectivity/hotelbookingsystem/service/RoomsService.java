package com.databaseconnectivity.hotelbookingsystem.service;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Rooms;

public interface RoomsService {
     void addRooms(Rooms rooms);
     Rooms getRoomsById(int id);
     List<Rooms> getAllRooms();
     void updateRoomStatus(int id , String status);
}
