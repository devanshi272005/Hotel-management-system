package com.databaseconnectivity.hotelbookingsystem.model;

public class Rooms {
   private int room_id;
   private String room_number;
   private int type_id;
   private String status;
   public Rooms() {
	super();
	// TODO Auto-generated constructor stub
   }
   public Rooms(int room_id, String room_number, int type_id, String status) {
	super();
	this.room_id = room_id;
	this.room_number = room_number;
	this.type_id = type_id;
	this.status = status;
   }
   public int getRoom_id() {
	return room_id;
   }
   public void setRoom_id(int room_id) {
	this.room_id = room_id;
   }
   public String getRoom_number() {
	return room_number;
   }
   public void setRoom_number(String room_number) {
	this.room_number = room_number;
   }
   public int getType_id() {
	return type_id;
   }
   public void setType_id(int type_id) {
	this.type_id = type_id;
   }
   public String getStatus() {
	return status;
   }
   public void setStatus(String status) {
	this.status = status;
   }
   @Override
   public String toString() {
	return "Rooms [room_id=" + room_id + ", room_number=" + room_number + ", type_id=" + type_id + ", status=" + status
			+ ", getRoom_id()=" + getRoom_id() + ", getRoom_number()=" + getRoom_number() + ", getType_id()="
			+ getType_id() + ", getStatus()=" + getStatus() + ", getClass()=" + getClass() + ", hashCode()="
			+ hashCode() + ", toString()=" + super.toString() + "]";
   }
   
}
