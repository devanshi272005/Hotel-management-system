package com.databaseconnectivity.hotelbookingsystem.service;

import java.util.List;

import com.databaseconnectivity.hotelbookingsystem.model.Customers;

public interface CustomersService {
   void addCustomers(Customers customers);
   Customers getCustomersById(int id);
   List<Customers> getAllCustomers();
   void updateCustomers(Customers customers);
   void deleteCustomers(int id);
}
