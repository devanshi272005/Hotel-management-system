package com.databaseconnectivity.hotelbookingsystem.controller;

import java.util.Scanner;

public class CustomersController {

    private Scanner sc = new Scanner(System.in);

    public CustomersController(Scanner sc2) {
		// TODO Auto-generated constructor stub
	}

	public void menu() {
        int choice;

        do {
            System.out.println("\n--- CUSTOMER MENU ---");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customers");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Add Customer logic");
                    break;
                case 2:
                    System.out.println("View Customers logic");
                    break;
                case 0:
                    System.out.println("Back to Main Menu...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 0);
    }
}
